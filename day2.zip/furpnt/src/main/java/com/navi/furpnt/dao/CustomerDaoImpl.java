package com.navi.furpnt.dao;


import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.navi.furpnt.model.Customer;
import com.navi.furpnt.model.UserRole;
@Repository
public class CustomerDaoImpl implements CustomerDao{

	@Autowired
	SessionFactory sessionFactroy;
		public void addCustomer(Customer customer){
			
			Session sesion=sessionFactroy.getCurrentSession();
			Transaction tx = sesion.beginTransaction();
			customer.setEnabled(true);
			sesion.save(customer);
			UserRole userRole=new UserRole();
			userRole.setAuthority("ROLE_USER");
			userRole.setUserid(customer.getCustomerId());
			sesion.save(userRole);
			
			
			tx.commit();
		
	}
		@Override
		public List<Customer> viewcustomer() {
			Session session=sessionFactroy.getCurrentSession();
			Transaction transaction=session.beginTransaction();
			List<Customer> list=session.createCriteria(Customer.class).list();
			return list;
		}

}
