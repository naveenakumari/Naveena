package com.bro.pink.dao;

import java.util.List;

import com.bro.pink.model.User;

public interface UserDao {
	public void saveOrUpdate (User user);
	public User getUserById(int userid);
	public  List<User> list();
	public User getUserByname(String username);
}
