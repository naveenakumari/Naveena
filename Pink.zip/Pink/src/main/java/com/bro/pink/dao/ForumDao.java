package com.bro.pink.dao;

import java.util.List;

import com.bro.pink.model.Forum;

public interface ForumDao 
{
	public void createNewForum(Forum f);
	public List<Forum> getForumList(String username);
	public void delete(int fid);
	public List<Forum> getForum();
}
