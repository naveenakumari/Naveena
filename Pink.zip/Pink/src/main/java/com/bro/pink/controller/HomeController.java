package com.bro.pink.controller;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.Principal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.bro.pink.model.User;
import com.bro.pink.service.UserService;

@Controller
public class HomeController 
{
	@Autowired
	UserService userservice;
	
	@RequestMapping("/")
	public ModelAndView LandPage()
	{
		return new ModelAndView("home");
	}
	
	@RequestMapping("/l")
	public ModelAndView LandlPage()
	{
		return new ModelAndView("Landing");
	}
	
	@RequestMapping("/signup")
	public ModelAndView signUpdata()
	{
		User user= new User();
		System.out.println("signup method called");
		return new ModelAndView("signup","userkey",user);
		
	}

	
	@RequestMapping("/navi")
	public ModelAndView disHome(Principal principal)
	{
		return new ModelAndView("login");
	}

	
	
	@RequestMapping("/register")
	public String createUser(@ModelAttribute("userkey") User user,@RequestParam("image") MultipartFile file) 
	{
		/*if(br.hasErrors())
		{
			System.out.println("error");
			return "signup";
		}*/
		System.out.println("register");
	    user.setName(user.getUsername());
	    user.setEnable(true);
	    user.setRole("ROLE_USER");
	    userservice.saveOrUpdate(user);
	    System.out.println("Data Inserted");
	    MultipartFile image = user.getImage();
	    /*String path = request.getSession().getServletContext().getRealPath("/WEB-INF/resources/images/"+user.getEmailid()+".jpg");*/
	    Path path=Paths.get("F://niit//workspace0//collabrationapp//src//main//webapp//WEB-INF//resources//images//"+user.getUserid()+".jpg");
	    System.out.println("Path="+path);
	    System.out.println("File name = " + user.getImage().getOriginalFilename());
	    if(image!=null && !image.isEmpty())
	    {
	        try
	        {
	            image.transferTo(new File(path.toString()));
	           System.out.println("Image saved  in:"+path.toString());
	        }
	        catch(Exception e)
	        {
	            e.printStackTrace();
	           System.out.println("Image not saved");
	        }
	    }	     	    
	    return "login";
	}
	    @RequestMapping("/login")
		public String loginMethod()
		{
	    	System.out.println("inside login");
			return "login";
		}		
}
