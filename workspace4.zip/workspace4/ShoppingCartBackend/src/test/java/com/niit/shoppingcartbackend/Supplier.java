package com.niit.shoppingcartbackend;

public class Supplier {

}
