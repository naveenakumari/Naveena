package com.navi.furpnt.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.navi.furpnt.model.Customer;
import com.navi.furpnt.model.Item;
import com.navi.furpnt.model.UserRole;

@Repository
public class ItemDaoImpl implements ItemDao {
	@Autowired
	SessionFactory sessionFactroy;

	public void addItem(Item item) {
		Session sesion = sessionFactroy.getCurrentSession();
		Transaction tx = sesion.beginTransaction();
		
		sesion.save(item);
		tx.commit();
		}

	
	

	@Override
	public List<Item> viewitem() {
		Session session=sessionFactroy.getCurrentSession();
		Transaction transaction=session.beginTransaction();
		List<Item> list=session.createCriteria(Item.class).list();
		return list;
	}
}
