package com.navi.furpnt.controller;

import java.io.IOException;
import java.util.List;

import org.apache.catalina.mapper.Mapper;
import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.navi.furpnt.model.Customer;
import com.navi.furpnt.model.Item;
import com.navi.furpnt.service.CustomerService;

@Controller
public class AdminController {
	@Autowired
 CustomerService c;
	@RequestMapping("/ViewCustomer")
	
public ModelAndView viewcustomer() throws JsonGenerationException, JsonMappingException, IOException
{
		List<Customer> list=c.viewcustomer();
		ObjectMapper mapper=new ObjectMapper();
		String ListJSON=mapper.writeValueAsString(list);
		System.out.println(ListJSON);
		return new ModelAndView("viewcustomer","listofcustomer",ListJSON);
		
}
	@RequestMapping("/additem")
	public ModelAndView addItem;
	{
		Item item=new Item();
		return new ModelAndView("addItem","Item",Item);
		
	}
	{
}
}