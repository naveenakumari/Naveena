package com.navi.furpnt.dao;

import java.util.List;


import com.navi.furpnt.model.Item;

public interface ItemDao {
	void addItem(Item item);
	List<Item> viewitem();

}
