package com.navi.furpnt.controller;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

import javax.validation.Valid;

import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.navi.furpnt.model.Customer;
import com.navi.furpnt.model.Item;
import com.navi.furpnt.service.CustomerService;
import com.navi.furpnt.service.ItemService;

@Controller
public class AdminController {
	@Autowired
	CustomerService c;
	@Autowired
	ItemService itemService;

	@RequestMapping("/ViewCustomer")
	public ModelAndView viewcustomer() throws JsonGenerationException, JsonMappingException, IOException {
		List<Customer> list = c.viewcustomer();
		ObjectMapper mapper = new ObjectMapper();
		String ListJSON = mapper.writeValueAsString(list);
		System.out.println(ListJSON);
		return new ModelAndView("viewcustomer", "listofcustomer", ListJSON);

	}

	@RequestMapping("/additem")
	public ModelAndView addItem() {
		Item item = new Item();
		return new ModelAndView("addItem", "i", item);
	}
	@RequestMapping("/addProduct")
	public ModelAndView addMyItem(@Valid @ModelAttribute("i") Item item, @RequestParam("file") MultipartFile file,
			BindingResult bindingResult) throws IllegalStateException, IOException {
		itemService.addItem(item);
		MultipartFile itemimage = item.getFile();
		Path path = Paths.get("F://niit//workspace6//furpnt//src//main//webapp//WEB-INF//resources//images//"
				+ item.getItemId() + ".jpg");
		if (itemimage != null && !itemimage.isEmpty()) {
			itemimage.transferTo(new File(path.toString()));
		}
		System.out.println("Item Name:" + item.getItemName());
		return new ModelAndView("viewItem");

	}
	@RequestMapping("/viewitem")
	public ModelAndView viewimage() throws JsonGenerationException, JsonMappingException, IOException {
		List<Item> list = itemService.viewitem();
		System.out.println("list:" + list);
		ObjectMapper mapper = new ObjectMapper();
		String itemJSON = mapper.writeValueAsString(list);
		System.out.println("JSON data:" + itemJSON);
		return new ModelAndView("viewItem", "listofitem", itemJSON);
	}
}
