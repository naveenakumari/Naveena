package com.navi.furpnt.controller;

import java.security.Principal;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.navi.furpnt.model.Customer;
import com.navi.furpnt.service.CustomerService;

import javafx.collections.ModifiableObservableListBase;

@Controller
public class HomeController {
	@Autowired
	CustomerService service;
	//this is the first request method for home//
	@RequestMapping("/")
	public ModelAndView home()
	{
		System.out.println("home() metod called");
		return  new ModelAndView("home");
	}
	//this is the second request method for signin//
	@RequestMapping("/signIn")
	public ModelAndView singInp()
	{
	System.out.println("sign in  metod called");
	return new ModelAndView("signin"); 
	}
	//this is the third request method for signup//
	@RequestMapping("/signUp")
	public ModelAndView signUp(){
		Customer customer=new Customer();
		System.out.println("signup is called");
		return new ModelAndView("signup","customerobj",customer);	
	}
	@RequestMapping("/login")
	public String loginMethod()
	{
		return "login";
	}

	@RequestMapping("/logout")
	public String logout(HttpServletRequest request)
	{
		request.getSession().invalidate();
		System.out.println("logout page called");

		return "logout";
		
	}
	 @RequestMapping("/CustomerCheck")
	 public ModelAndView customerCheck(Principal principal )
	 {	
		System.out.println("UserName:"+principal.getName());
		return new ModelAndView("customerhome");
	 }
	 @RequestMapping("/AdminCheck")
	 public ModelAndView adminCheck(Principal principal )
	 {
		System.out.println("UserName:"+principal.getName());
		return new ModelAndView("adminhome");
	 }
	@RequestMapping("/register")
	//@valid for validation of customer
	public ModelAndView register(@Valid@ModelAttribute("customerobj") Customer customer,BindingResult bindingresult)
	{
		if(bindingresult.hasErrors()){
			return new ModelAndView("signup");
		}
		System.out.println("UserName:"+customer.getUsername());
		System.out.println("Password:"+customer.getPassword());
		service.addCustomer(customer);
		return new ModelAndView("signup");

	}
	
}